const levelPalettes = [
    // Nível 1 - Circuito Neon Futurista (Fácil)
    {
        background: {
            A1: '#000033', // Azul Muito Escuro
            A2: '#1a1a40', // Azul Acinzentado
            B1: '#240050', // Roxo Escuro
            B2: '#993399'  // Azul Muito Escuro
        },
        paddleColor: '#00FFFF', // Neon Azul Ciano
        brickColor: '#00FFFF',  // Neon Azul Ciano
        ballColor: '#00FFFF'    // Neon Azul Ciano
    }, 
    // Nível 2 - Space Invader (Moderado)
    {
        background: {
            A1: '#0D0D0D', // Cinza Muito Escuro
            A2: '#1C1C1C', // Cinza Escuro
            B1: '#2E2E2E', // Cinza Médio
            B2: '#3F3F3F'  // Cinza Claro
        },
        paddleColor: '#00FF00', // Verde Limão (contraste alto)
        brickColor: '#7FFF00',  // Chartreuse (contraste alto)
        ballColor: '#ADFF2F'    // Amarelo-Verde (contraste alto)
    },    
    // Nível 3 - Nave Espacial (Moderado)
    {
        background: {
            A1: '#001A00', // Verde Muito Escuro
            A2: '#003300', // Verde Escuro
            B1: '#004D00', // Verde Médio Escuro
            B2: '#006600'  // Verde
        },
        paddleColor: '#FFFFFF', // Branco
        brickColor: '#FFFFFF',  // Branco
        ballColor: '#FFFFFF'    // Branco
    },    
    // Nível 4 - Estrela (Moderado)
    {
        background: {
            A1: '#000000', // Preto
            A2: '#000020', // Azul Muito Escuro
            B1: '#000040', // Azul Escuro
            B2: '#000000'  // Preto
        },
        paddleColor: '#FFFF00', // Amarelo
        brickColor: '#FFFF00',  // Amarelo
        ballColor: '#FFFF00'    // Amarelo
    },    
    // Nível 5 - Planeta com Anéis (Moderado)
    {
        background: {
            A1: '#000033', // Azul Muito Escuro
            A2: '#000044', // Azul Escuro
            B1: '#000055', // Azul Médio Escuro
            B2: '#000066'  // Azul Escuro
        },
        paddleColor: '#FFD700', // Ouro (contraste alto)
        brickColor: '#FFA500',  // Laranja (contraste alto)
        ballColor: '#FFFFFF'    // Branco (contraste alto)
    },    
    // Nível 6 - Coração (Moderado)
    {
        background: {
            A1: '#FFB6C1', // Rosa Claro
            A2: '#FFC0CB', // Rosa
            B1: '#FF69B4', // Rosa Choque
            B2: '#FF1493'  // Rosa Profundo
        },
        paddleColor: '#FFFFFF', // Branco
        brickColor: '#FFFFFF',  // Branco
        ballColor: '#FFFFFF'    // Branco
    },    
    // Nível 7 - Símbolo de Energia (Difícil)
    {
        background: {
            A1: '#000000', // Preto
            A2: '#000033', // Azul Muito Escuro
            B1: '#000066', // Azul Escuro
            B2: '#0000FF'  // Azul Brilhante
        },
        paddleColor: '#FFFF00', // Amarelo (contraste alto)
        brickColor: '#FFD700',  // Ouro (contraste alto)
        ballColor: '#FFFFFF'    // Branco (contraste alto)
    },    
    // Nível 8 - Circuito (Difícil)
    {
        background: {
            A1: '#0D0D0D', // Cinza Muito Escuro
            A2: '#1C1C1C', // Cinza Escuro
            B1: '#333333', // Cinza Médio
            B2: '#4F4F4F'  // Cinza Claro
        },
        paddleColor: '#00FF00', // Verde Limão
        brickColor: '#00FF00',  // Verde Limão
        ballColor: '#7CFC00'    // Verde Grama
    },    
    // Nível 9 - Robô (Difícil)
    {
        background: {
            A1: '#1C1C1C', // Cinza Muito Escuro
            A2: '#2F4F4F', // Cinza Ardósia Escuro
            B1: '#4F4F4F', // Cinza Escuro
            B2: '#696969'  // Cinza
        },
        paddleColor: '#00FFFF', // Ciano (contraste alto)
        brickColor: '#00CED1',  // Turquesa Escuro (contraste alto)
        ballColor: '#7FFFD4'    // Água-marinha (contraste alto)
    },    
    // Nível 10 - Portal (Difícil)
    {
        background: {
            A1: '#4B0082', // Índigo
            A2: '#6A0DAD', // Roxo Escuro
            B1: '#8A2BE2', // Azul Violeta
            B2: '#BA55D3'  // Orquídea Média
        },
        paddleColor: '#FFFFFF', // Branco
        brickColor: '#FFFF00',  // Amarelo
        ballColor: '#ADFF2F'    // Amarelo-Verde
    },    
    // Nível 11 - Alienígena (Muito Difícil)
    {
        background: {
            A1: '#001A00', // Verde Muito Escuro
            A2: '#003300', // Verde Escuro
            B1: '#004D00', // Verde Médio Escuro
            B2: '#006600'  // Verde
        },
        paddleColor: '#FF00FF', // Magenta (contraste alto)
        brickColor: '#FF1493',  // Rosa Profundo (contraste alto)
        ballColor: '#FFFF00'    // Amarelo (contraste alto)
    },    
    // Nível 12 - Foguete (Muito Difícil)
    {
        background: {
            A1: '#000000', // Preto
            A2: '#0D0D0D', // Cinza Muito Escuro
            B1: '#1A1A1A', // Cinza Escuro
            B2: '#262626'  // Cinza Médio
        },
        paddleColor: '#FFFFFF', // Branco
        brickColor: '#FF4500',  // Laranja Vermelho (contraste alto)
        ballColor: '#FFFF00'    // Amarelo (contraste alto)
    },    
    // Nível 13 - Satélite (Muito Difícil)
    {
        background: {
            A1: '#000000', // Preto
            A2: '#000033', // Azul Muito Escuro
            B1: '#000066', // Azul Escuro
            B2: '#000099'  // Azul
        },
        paddleColor: '#FFFFFF', // Branco
        brickColor: '#00BFFF',  // Azul Deep Sky (contraste alto)
        ballColor: '#00FFFF'    // Água (contraste alto)
    },    
    // Nível 14 - Buraco Negro (Muito Difícil)
    {
        background: {
            A1: '#000000', // Preto
            A2: '#0A0A0A', // Cinza Muito Escuro
            B1: '#151515', // Cinza Escuro
            B2: '#1F1F1F'  // Cinza Médio
        },
        paddleColor: '#FF4500', // Laranja Vermelho (contraste alto)
        brickColor: '#FFD700',  // Ouro (contraste alto)
        ballColor: '#FFFFFF'    // Branco (contraste alto)
    },    
    // Nível 15 - DNA (Muito Difícil)
    {
        background: {
            A1: '#000033', // Azul Muito Escuro
            A2: '#000066', // Azul Escuro
            B1: '#000099', // Azul Médio Escuro
            B2: '#0000CC'  // Azul Médio
        },
        paddleColor: '#FF69B4', // Rosa Choque (contraste alto)
        brickColor: '#ADFF2F',  // Amarelo-Verde (contraste alto)
        ballColor: '#FFFF00'    // Amarelo (contraste alto)
    },    
    // Nível 16 - Circuito Complexo (Extremo)
    {
        background: {
            A1: '#0D0D0D', // Cinza Muito Escuro
            A2: '#1A1A1A', // Cinza Escuro
            B1: '#262626', // Cinza Médio
            B2: '#333333'  // Cinza Claro
        },
        paddleColor: '#00FF00', // Verde Limão
        brickColor: '#7CFC00',  // Verde Grama (contraste alto)
        ballColor: '#ADFF2F'    // Amarelo-Verde (contraste alto)
    },    
    // Nível 17 - Planeta com Anéis Duplos (Extremo)
    {
        background: {
            A1: '#000033', // Azul Muito Escuro
            A2: '#000044', // Azul Escuro
            B1: '#000055', // Azul Médio Escuro
            B2: '#000066'  // Azul Escuro
        },
        paddleColor: '#FFD700', // Ouro
        brickColor: '#FFA500',  // Laranja
        ballColor: '#FFFFFF'    // Branco
    },    
    // Nível 18 - Olho Cibernético (Extremo)
    {
        background: {
            A1: '#1C1C1C', // Cinza Muito Escuro
            A2: '#2E2E2E', // Cinza Escuro
            B1: '#3F3F3F', // Cinza Médio
            B2: '#4F4F4F'  // Cinza Claro
        },
        paddleColor: '#FF0000', // Vermelho
        brickColor: '#FFFF00',  // Amarelo
        ballColor: '#FFFFFF'    // Branco
    },    
    // Nível 19 - Mão Robótica (Extremo)
    {
        background: {
            A1: '#0D0D0D', // Cinza Muito Escuro
            A2: '#1C1C1C', // Cinza Escuro
            B1: '#2E2E2E', // Cinza Médio
            B2: '#3F3F3F'  // Cinza Claro
        },
        paddleColor: '#00FFFF', // Ciano (contraste alto)
        brickColor: '#00CED1',  // Turquesa Escuro (contraste alto)
        ballColor: '#7FFFD4'    // Água-marinha (contraste alto)
    },
    // Nível 20 - Portal Final (Extremo)
    {
        background: {
            A1: '#8B008B', // Magenta Escuro
            A2: '#4B0082', // Índigo
            B1: '#0000FF', // Azul
            B2: '#00FFFF'  // Ciano
        },
        paddleColor: '#FFFF00', // Amarelo (contraste alto)
        brickColor: '#FFD700',  // Ouro (contraste alto)
        ballColor: '#FFFFFF'    // Branco (contraste alto)
    }   
];
