const maxStatus = 3;

const levelMaps = [
    // Level 1 - Circuito Neon (Fácil)
    [
        "    111111111    ",
        "   1         1   ",
        "  1  P     P  1  ",
        " 1   1111111   1 ",
        "1    1     1    1",
        "1    1     1    1",
        " 1   1 1 1 1   1 ",
        "  1  P     P  1  ",
    ],
    // Level 2 - Space Invader (Moderado)
    [
        "    1111   ",
        "   122221  ",
        "  P 2 2 2 P",
        " 1111111111",
        "1 1 1 1 1 1",
        "P        P ",
        "           ",
    ],
    // Level 3 - Nave Espacial (Moderado)
    [
        "     1P1     ",
        "    1   1    ",
        "   1 3 3 1   ",
        "  1  333  1  ",
        " 1    3    1 ",
        "1    1 1    1",
        "     P P     ",
    ],
    // Level 4 - Estrela (Moderado)
    [
        "     P      ",
        "    1 1     ",
        "   P   P    ",
        "  1  P  1   ",
        " 1111111111 ",
        "  1  P  1   ",
        "   P   P    ",
        "    1 1     ",
        "     P      ",
    ],
    // Level 5 - Planeta com Anéis (Moderado)
    [
        "     1     ",
        "    222    ",
        "   22P22   ",
        "  2222222  ",
        "12222P22221",
        "  2222222  ",
        "   22P22   ",
        "    222    ",
        "     1     ",
    ],
    // Level 6 - Coração (Moderado)
    [
        "  P     P  ",
        " 313   313 ",
        "31113 31113",
        " 311131113 ",
        "  3111113  ",
        "   31113   ",
        "    313    ",
        "     P     ",
    ],
    // Level 7 - Símbolo de Energia (Difícil)
    [
        "     P     ",
        "     P     ",
        "    3P3    ",
        "   32U23   ",
        "  321U123  ",
        "     U     ",
        "     U     ",
    ],
    // Level 8 - Circuito (Difícil)
    [
        "2 2 2 2 2 2",
        " 222 222 22",
        "  P   P   P",
        " 222 222 22",
        "2 2 2 2 2 2",
        " U  U  U  U",
        "2 2 2 2 2 2",
    ],
    // Level 9 - Robô (Difícil)
    [
        "   333333   ",
        "  3 P   P 3 ",
        " 3333333333 ",
        "3   UUUU   3",
        "3  3    3  3",
        "   P    P   ",
        "   3    3   ",
    ],
    // Level 10 - Portal (Difícil)
    [
        "    UUUU   ",
        "  UU    33 ",
        " 33 PP  33 ",
        " 33 PP  33 ",
        " 33    33 ",
        "  UU  UU  ",
        "   UUUU   ",
    ],
    // Level 11 - Alienígena (Muito Difícil)
    [
        "    UUUU    ",
        "   U    U   ",
        "  2 UUUU 2  ",
        " 2 2  2  2 2",
        "P  2  2  2  P",
        "    2  2    ",
        "   P    P   ",
    ],
    // Level 12 - Foguete (Muito Difícil)
    [
        "     P     ",
        "     3     ",
        "    333    ",
        "   3 3 3   ",
        "  3  3  3  ",
        " P   3   P ",
        "     3     ",
        "     3     ",
    ],
    // Level 13 - Satélite (Muito Difícil)
    [
        "1 1       1 1",
        " 1 1     1 1 ",
        "  1 1   1 1  ",
        "   UPUPUPU   ",
        "  1 1   1 1  ",
        " 1 1     1 1 ",
        "1 1       1 1",
    ],
    // Level 14 - Buraco Negro (Muito Difícil)
    [
        "   33333   ",
        "  3UUUUU3  ",
        " 3333P3333 ",
        "3U333P333U3",
        "3U333P333U3",
        " 333333333 ",
        "  3UUUUU3  ",
        "   33333   ",
    ],
    // Level 15 - DNA (Difícil)
    [
        "1   2   P   2",
        " 1 2     1 2 ",
        "  12       12",
        "   U       U ",
        "  12       12",
        " 1 2     1 2 ",
        "1   2   P   2",
    ],
    // Level 16 - Circuito Complexo (Extremo)
    [
        "2 2 2 2 2 2 2 2",
        " UUU UUU UUU 22",
        "  P   P   P   P",
        " UUU UUU UUU 22",
        "2 2 2 2 2 2 2 2",
        " 2  2  2  2  2 ",
        "2 2 2 2 2 2 2 2",
    ],
    // Level 17 - Planeta com Anéis Duplos (Extremo)
    [
        "     UU     ",
        "    3333    ",
        "   333333   ",
        "  33333333  ",
        " 3333333333 ",
        "P2222222222P",
        " 3333333333 ",
        "  33333333  ",
        "   333333   ",
        "    3333    ",
        "     UU     ",
    ],
    // Level 18 - Olho Cibernético (Extremo)
    [
        "    33333    ",
        "  UU     UU  ",
        " U   PPP   U ",
        "1   P333P   1",
        "1   P333P   1",
        " U   PPP   U ",
        "  UU     UU  ",
        "    33333    ",
    ],
    // Level 19 - Mão Robótica (Extremo)
    [
        "3  3  P  3  3",
        " 3 3  U  3 3 ",
        "  3   U   3  ",
        " U U  P  U U ",
        "3  3  U  3  3",
        "      U      ",
        "      P      ",
    ],
    // Level 20 - Portal Final (Extremo)
    [
        "UUUUUUUUUUUUUU",
        "23333333333332",
        "23P3P3P3P3P3P2",
        "23333333333332",
        "1UUUU3333UUUU1",
        "     PPPP     ",
        "    UUUUUU    ",
        "     UUUU     ",
    ],
];