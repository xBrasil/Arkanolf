let gameDifficulties = [
    {
        difficultyName: "Electro Novice", // Easy
        initialLives: 5,
        speedMultiplier: 1,
        speedIncreaseTotal: 0.5,
        speedIncreaseMax: 3,
        scoreMultiplier: 0.5,
        ballSizeMultiplier: 1.3,
        padSizeMultiplier: 1.3
    },
    {
        difficultyName: "Neon Warrior", // Normal
        initialLives: 3,
        speedMultiplier: 1,
        speedIncreaseTotal: 1,
        speedIncreaseMax: 2,
        scoreMultiplier: 1,
        ballSizeMultiplier: 1.2,
        padSizeMultiplier: 1.2
    },
    {
        difficultyName: "Pulse Master", // Hard
        initialLives: 2,
        speedMultiplier: 1.5,
        speedIncreaseTotal: 0.7,
        speedIncreaseMax: 2,
        scoreMultiplier: 2.5,
        ballSizeMultiplier: 1,
        padSizeMultiplier: 1
    },
    {
        difficultyName: "Synth Overlord", // Legendary
        initialLives: 0,
        speedMultiplier: 1.5,
        speedIncreaseTotal: 1,
        speedIncreaseMax: 3,
        scoreMultiplier: 5,
        ballSizeMultiplier: 0.8,
        padSizeMultiplier: 0.8
    }
];
let difficultyConfig = gameDifficulties[0];