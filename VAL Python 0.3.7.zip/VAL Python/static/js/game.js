// Configurações globais
const GAME_AREA_WIDTH_PERCENTAGE = 0.5;
const GAME_AREA_HEIGHT_PERCENTAGE = 0.85;
const GAME_NAME = 'Arkanolf.com';
const GAME_VERSION = '0.3.8';
const GAME_NAME_HUD = 'Arkanolf';
const GAME_AUTHOR = 'Rodolfo Motta Saraiva';
const GAME_BASE_HIT_POINTS = 10;
const GAME_POWERUP_HIT_POINTS = 50;
const GAME_LIFELOSS_POINTS_PENALTY = 100;
const GAME_LEVELCOMPLETE_POINTS = 200;
const GAME_FONT_ROBOTO = 'px Roboto, Arial, sans-serif';
const GAME_FONT_ARIAL = 'px Arial, sans-serif';
const HUD_SEPARATOR = '     ';

const BASE_BALL_SPEED_RATIO = 0.45;

// POWER UPS
const POWERUP_DURATION = 20; // in seconds
const FIREBALL_DURATION = 15; // in seconds
const POWERUP_FASTBALL_MULTIPLIER = 1.5;
const POWERUP_SLOWBALL_MULTIPLIER = 0.75;
let powerupBigPaddleMultiplier = 1;
const POWERUP_TYPES = [
    FIREBALL=0,
    MULTIBALL=1,
    BIGPADDLE=2,
    FASTBALL=3,
    EXTRALIFE=4,
    SLOWBALL=5
]
let activePowerupBalspeedModifier = 1;
let powerupTimeouts = []; // Array para armazenar os IDs dos timeouts

let activePowerUps = {
    fastball: 0,
    slowball: 0,
    fireball: 0
};

// Seleciona o canvas e o contexto de desenho
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let oldCanvasWidth = 0; // força resizeCanvas() a executar certas funções ao menos uma vez
let oldCanvasHeight = 0; // força resizeCanvas() a executar certas funções ao menos uma vez
let canvasDiagonal = 0;

// Variáveis globais
let gameState = 'intro'; // Possíveis estados: 'intro', 'startMenu', 'playing', 'paused', 'levelCompleted', 'gameOver', 'gameCompleted'
let isPaused = false;
let isInitialBall = true;
let levelCompletionTime;
let gameCompletionTime;

let menuParticles = []; // Array para armazenar partículas do menu inicial
let startButtons = []; // Array para armazenar os botões de dificuldade
let mouseX = 0, mouseY = 0; // Variáveis globais para armazenar a posição do mouse
let rightPressed=false, leftPressed=true;

const levelCompletionDuration = 3000; // Duração da animação de nível concluído (3 segundos)
const gameCompletionDuration = 5000;  // Duração da animação de jogo concluído (5 segundos)

let introDuration = 3000; // Duração em milissegundos (3 segundos)
let introStartTime = Date.now();
let introParticles = [];

// Array global para armazenar as partículas da fireball
let fireParticles = [];

let eventListenersAdded = false;

let paddle, bricks, particles, powerUps;
let balls = []; // Array de bolas
let brickRowCount, brickColumnCount;
let score, lives, level;
let effects = [];

const PARTICLE_SPEED = 200; // Velocidade das partículas em pixels por segundo
const PARTICLE_LIFE = 0.5;  // Vida das partículas em segundos
const FIRE_PARTICLE_SPEED = 200; // pixels por segundo
const FIRE_PARTICLE_LIFE = 0.5;  // segundos
const FIRE_PARTICLE_SIZE = 6;    // tamanho inicial das partículas
const MENU_PARTICLE_SPEED = 100; // Velocidade das partículas de menu em pixels por segundo

let brickWidth, brickHeight, brickPadding, paddleWidth, paddleHeight, offsetTop, offsetLeft, backgroundColorA, backgroundColorB;

let lastFrameTime = Date.now(); // Tempo do último quadro em milissegundos
let backgroundTime = 0;
let menuBackgroundTime = 0;
let levelCompletionElapsedTime = 0;

// Função para ajustar o tamanho do canvas
function resizeCanvas(forceUpdate=false) {
    // Tamanho original da janela
    let windowWidth = window.innerWidth;
    let windowHeight = window.innerHeight;

    // Calcular a proporção atual da janela
    let aspectRatio = windowWidth / windowHeight;

    // Ajustar proporções para garantir que não ultrapasse 3:2 ou 2:3
    if (aspectRatio > 3 / 2) {
        // Se a largura for muito maior que a altura (maior que 3:2)
        windowWidth = windowHeight * (3 / 2);
    } else if (aspectRatio < 2 / 3) {
        // Se a altura for muito maior que a largura (menor que 2:3)
        windowHeight = windowWidth * (3 / 2);
    }

    // Aplicar porcentagens de área de jogo (ajuste final para GAME_AREA_WIDTH_PERCENTAGE e GAME_AREA_HEIGHT_PERCENTAGE)
    canvas.width = windowWidth * GAME_AREA_WIDTH_PERCENTAGE;
    canvas.height = windowHeight * GAME_AREA_HEIGHT_PERCENTAGE;

    // Atualizar o valor da diagonal do canvas
    canvasDiagonal = Math.sqrt(canvas.width ** 2 + canvas.height ** 2);

    if (canvas.width != oldCanvasWidth || canvas.height != oldCanvasHeight || forceUpdate) {
        if (menuParticles) {
            // Recriar partículas quando o tamanho do canvas muda
            menuParticles = [];
            createMenuParticles();
        }
        if (introParticles) {
            introParticles = [];
            createIntroParticles();
        }
        // Recalcular tamanhos e posições dos elementos do jogo se o jogo estiver em andamento
        if (gameState === 'playing' || gameState === 'levelCompleted' || gameState === 'gameCompleted') {
            resizeGameElements();
        }
    }

    // Armazenar as dimensões atuais do canvas
    oldCanvasWidth = canvas.width;
    oldCanvasHeight = canvas.height;    
}

function calcBallSpeed() {
    const baseSpeed = canvas.height * BASE_BALL_SPEED_RATIO; // Velocidade base em pixels por segundo
    const levelSpeedMultiplier = 1 + (level * difficultyConfig.speedIncreaseTotal / levelMaps.length);
    const speed = baseSpeed * difficultyConfig.speedMultiplier * levelSpeedMultiplier * activePowerupBalspeedModifier;
    return Math.min(speed, baseSpeed * difficultyConfig.speedIncreaseMax);
}

function calcBallSize() {
    return canvasDiagonal * 0.012 * difficultyConfig.ballSizeMultiplier;
}

function calcPaddleWidth() {
    if (powerupBigPaddleMultiplier<1)powerupBigPaddleMultiplier=1;
    return canvas.width * 0.2 * difficultyConfig.padSizeMultiplier * powerupBigPaddleMultiplier;
}

function calcPaddleHeight() {
    return canvas.height * 0.02 * difficultyConfig.padSizeMultiplier;
}

function calcPaddleY(paddleHeight) {
    return canvas.height - paddleHeight * 3;
}

function calcPaddleSpeed() {
    return canvas.width * 0.75 * difficultyConfig.speedMultiplier; // Velocidade de 50% da largura do canvas por segundo
}

function resizeGameElements() {
    // Armazenar as dimensões anteriores do canvas
    let previousCanvasWidth = oldCanvasWidth || canvas.width;
    let previousCanvasHeight = oldCanvasHeight || canvas.height;

    // Recalcular tamanhos proporcionais ao canvas
    paddleWidth = calcPaddleWidth();
    paddleHeight = calcPaddleHeight();
    ballRadius = calcBallSize();
    brickPadding = canvasDiagonal * 0.006;

    brickHeight = canvas.height * 0.05;
    brickWidth = (canvas.width - (1 + 1) * brickPadding) / 1;
    if (brickColumnCount) {
        brickWidth = (canvas.width - (brickColumnCount + 1) * brickPadding) / brickColumnCount;
    }

    // Atualizar paddle
    if (paddle) {
        paddle.width = paddleWidth;
        paddle.height = paddleHeight;
        paddle.y = calcPaddleY(paddleHeight);
        paddle.speed = calcPaddleSpeed();

        // Manter a posição x da paddle dentro dos limites
        if (paddle.x < 0) {
            paddle.x = 0;
        } else if (paddle.x + paddle.width > canvas.width) {
            paddle.x = canvas.width - paddle.width;
        }
    }
    
    if (fireParticles) {
        // Recriar partículas quando o tamanho do canvas muda
        fireParticles = [];
    }
    // Atualizar ball
    for (let ball of balls) {
        // Recalcular o raio da bola
        ball.radius = ballRadius;

        // Recalcular a velocidade da bola
        ballSpeed = calcBallSpeed();
        ball.speed = ballSpeed;

        // Recalcular dx e dy para manter a direção
        let angle = Math.atan2(ball.dy, ball.dx);
        ball.dx = ballSpeed * Math.cos(angle);
        ball.dy = ballSpeed * Math.sin(angle);

        // Ajustar posição da bola proporcionalmente
        ball.x = (ball.x / previousCanvasWidth) * canvas.width;
        ball.y = (ball.y / previousCanvasHeight) * canvas.height;

        if (ball.isFireball) createFireParticles(ball);
    }

    // Atualizar bricks
    offsetTop = canvas.height * 0.1;
    offsetLeft = (canvas.width - (1 * (brickWidth + brickPadding))) / 2;
    if (bricks && brickColumnCount && brickRowCount) {
        offsetLeft = (canvas.width - (brickColumnCount * (brickWidth + brickPadding))) / 2;

        for (let r = 0; r < brickRowCount; r++) {
            for (let c = 0; c < brickColumnCount; c++) {
                let b = bricks[r][c];
                if (b) {
                    b.width = brickWidth;
                    b.height = brickHeight;
                    b.x = c * (brickWidth + brickPadding) + offsetLeft;
                    b.y = r * (brickHeight + brickPadding) + offsetTop;
                }
            }
        }
    }

    // Atualizar power-ups
    if (powerUps) {
        for (let pu of powerUps) {
            // Recalcular tamanho do power-up se necessário
            pu.width = canvas.width * 0.05;
            pu.height = canvas.height * 0.02;

            // Ajustar posição dos power-ups proporcionalmente
            pu.x = (pu.x / previousCanvasWidth) * canvas.width;
            pu.y = (pu.y / previousCanvasHeight) * canvas.height;
        }
    }

    // Atualizar efeitos
    if (effects) {
        for (let effect of effects) {
            effect.x = (effect.x / previousCanvasWidth) * canvas.width;
            effect.y = (effect.y / previousCanvasHeight) * canvas.height;
        }
    }

    // Atualizar partículas
    if (particles) {
        for (let p of particles) {
            p.x = (p.x / previousCanvasWidth) * canvas.width;
            p.y = (p.y / previousCanvasHeight) * canvas.height;
            p.dx = (p.dx / previousCanvasWidth) * canvas.width;
            p.dy = (p.dy / previousCanvasHeight) * canvas.height;
        }
    }

    // Armazenar as dimensões atuais para o próximo redimensionamento
    oldCanvasWidth = canvas.width;
    oldCanvasHeight = canvas.height;
}

function initLevel() {
    // Reiniciar a bola e posição da raquete
    paddleWidth = calcPaddleWidth();
    paddleHeight = calcPaddleHeight();
    if (paddle) {
        paddle.x = canvas.width / 2 - paddleWidth / 2;       
    } else {
        paddle = {
            x: canvas.width / 2 - paddleWidth / 2,
            previousX: canvas.width / 2 - paddleWidth / 2,
            y: calcPaddleY(paddleHeight),
            previousY: calcPaddleY(paddleHeight),
            width: paddleWidth,
            height: paddleHeight,
            dx: 0,
            speed: calcPaddleSpeed() // Velocidade em unidades por segundo
        };
    }

    const ballSpeed = calcBallSpeed();
    const ballRadius = calcBallSize();

    // Inicializar a bola principal
    balls = [{
        x: canvas.width / 2,
        y: paddle.y - ballRadius,
        radius: ballRadius,
        speed: ballSpeed, // Velocidade em unidades por segundo
        dx: ballSpeed * (Math.random() * 2 - 1),
        dy: -ballSpeed,
        isFireball: false // Indica se a bola é uma fireball
    }];

    particles = [];
    fireParticles = [];
    powerUps = [];
    effects = [];
    cancelPowerUpTimeouts();
    activePowerUps.fastball = 0;
    activePowerUps.slowball = 0;
    activePowerUps.fireball = 0;
    activePowerupBalspeedModifier = 1;
    powerupBigPaddleMultiplier = 1;
    isInitialBall = true;
}

function resetGame() {
    if (!difficultyConfig) {
        // if not found, falls back to default
        difficultyConfig = gameDifficulties[0];
    }
    lives = difficultyConfig.initialLives;
    level = 1;
    score = 0;
}

// Inicialização dos elementos do jogo
function init() {
    resizeCanvas(true);

    // Recalcular tamanhos proporcionais ao canvas
    ballRadius = calcBallSize();

    // Inicializar o level
    initLevel();

    // Get the map for the current level
    const levelMap = levelMaps[(level - 1) % levelMaps.length];

    brickRowCount = levelMap.length;
    brickColumnCount = levelMap.reduce((max, row) => Math.max(max, row.length), 0);

    bricks = [];

    brickWidth = (canvas.width - (brickColumnCount + 1) * brickPadding) / brickColumnCount;
    brickHeight = canvas.height * 0.05;

    // Inicialização dos blocos
    for (let r = 0; r < brickRowCount; r++) {
        bricks[r] = [];
        for (let c = 0; c < brickColumnCount; c++) {
            let char = levelMap[r][c] || ' ';
            let status = 0;
            let hasPowerUp = false;
            let unbreakable = false;

            switch (char) {
                case "1":
                    status = 1; // Bloco simples
                    break;
                case "2":
                    status = 2; // Bloco reforçado
                    break;
                case "3":
                    status = 3; // Bloco super reforçado
                    break;
                case "P":
                    status = 1; // Bloco simples com power-up
                    hasPowerUp = true;
                    break;
                case "U":
                    status = -1; // Bloco inquebrável
                    unbreakable = true;
                    break;
                default:
                    status = 0;
            }

            if (status !== 0) {
                bricks[r][c] = {
                    x: 0,
                    y: 0,
                    width: brickWidth,
                    height: brickHeight,
                    status: status,
                    hasPowerUp: hasPowerUp,
                    unbreakable: unbreakable
                };
            } else {
                bricks[r][c] = null;
            }
        }
    }

    gameState='playing'
    resizeCanvas(true);
}

// Função principal do loop do jogo
function gameLoop() {
    const now = Date.now();
    let deltaTime = (now - lastFrameTime) / 1000; // Converter para segundos
    lastFrameTime = now;
    requestAnimationFrame(gameLoop);

    switch(gameState) {
        case 'intro':
            drawIntro(deltaTime);
            if (Date.now() - introStartTime >= introDuration) gameState = 'startMenu';
            break;
        case 'startMenu':
            if (!eventListenersAdded) {
                document.addEventListener('keydown', keyDownHandler);
                document.addEventListener('keyup', keyUpHandler);
                document.addEventListener('keydown', function(event) {
                    if (event.code === 'Space') {
                        if (isInitialBall) {
                            isInitialBall = false;
                        } else {
                            togglePause();
                        }
                    }
                });
                addMouseEventsListeners();
    
                eventListenersAdded = true;
            }
            drawStartMenu(deltaTime);
            break;
        case 'playing':   
            update(deltaTime);
            render(deltaTime);
            break;
        case 'levelCompleted':
            drawLevelCompletion(deltaTime);

            if (Date.now() - levelCompletionTime >= levelCompletionDuration) {
                level++;
                if (level > levelMaps.length) {
                    gameState = 'gameCompleted';
                    gameCompletionTime = Date.now();
                } else {
                    init();
                }
            }
            break;
        case 'gameCompleted':
            drawGameCompletion(deltaTime);

            if (Date.now() - gameCompletionTime >= gameCompletionDuration) {
                // Reiniciar o jogo
                gameState = 'intro';
                introStartTime = Date.now();
            }
            break;
        case 'gameOver':
            drawGameOverScreen(deltaTime);

            break;
    }
}

// Atualiza o estado do jogo
function update(deltaTime) {
    if (isPaused) return;
    updatePaddle(deltaTime);
    if (!isInitialBall) {
        updatePowerUpEffects(deltaTime);
        if (!moveBalls(deltaTime)) { return; } // se moveBalls levar à perda de uma vida ou fim de jogo, não segue processando
        ballCollisionDetection();
        collisionDetection();
        movePowerUps(deltaTime);
    }
    updateParticles(deltaTime);
    updateEffects(deltaTime);
}

// Renderiza os elementos do jogo
function render(deltaTime) {
    clearCanvas();
    drawPulsatingBackground(level, deltaTime);
    drawBricks();
    drawPaddle();
    drawFireParticles(); // Desenhar as partículas de fogo antes das bolas
    drawBalls();
    drawParticles(); // Desenha as demais partículas depois das bolas
    drawPowerUps();
    drawHUD();
    drawEffects();

    if (isPaused && gameState === 'playing') drawPauseScreen();
}

// Limpa o canvas
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function createIntroParticles() {
    for (let i = 0; i < 100; i++) {
        introParticles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            dx: (Math.random() - 0.5) * 2,
            dy: (Math.random() - 0.5) * 2,
            radius: Math.random() * 2 + 1,
            alpha: Math.random()
        });
    }
}

function updateIntroParticles(deltaTime) {
    for (let p of introParticles) {
        p.x += p.dx * deltaTime * 60;
        p.y += p.dy * deltaTime * 60;

        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
    }
}

function drawIntroParticles() {
    for (let p of introParticles) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255,' + p.alpha + ')';
        ctx.fill();
    }
}

function drawIntro(deltaTime) {
    // Limpar o canvas
    clearCanvas();

    // Fundo com gradiente animado
    let gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#8E2DE2');
    gradient.addColorStop(1, '#4A00E0');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Atualizar e desenhar partículas
    updateIntroParticles(deltaTime);
    drawIntroParticles();

    // Efeito de brilho pulsante
    let time = Date.now() * 0.002;
    let alpha = 0.5 + Math.sin(time) * 0.5;

    // Configurar o texto
    ctx.font = 'bold ' + canvas.width * 0.1 + GAME_FONT_ARIAL;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255, 255, 255, ' + alpha + ')';
    ctx.shadowColor = 'rgba(255, 255, 255, ' + alpha + ')';
    ctx.shadowBlur = 20;

    // Desenhar o texto
    ctx.fillText(GAME_NAME, canvas.width / 2, canvas.height / 2);

    // Resetar sombra
    ctx.shadowBlur = 0;
}

// Desenha o fundo
function drawPulsatingBackground(level, deltaTime) {
    backgroundTime += deltaTime;

    const palette = levelPalettes[(level - 1) % levelPalettes.length];
    const { A1, A2, B1, B2 } = palette.background;

    // Calcular o fator de pulsação baseado no tempo acumulado
    const time = backgroundTime * 0.5 * difficultyConfig.speedMultiplier; // Ajuste a velocidade conforme necessário
    const pulse = (Math.sin(time) + 1) / 2; // Varia entre 0 e 1

    // Interpolar as cores A e B entre suas variações
    backgroundColorA = interpolateColor(A1, A2, pulse);
    backgroundColorB = interpolateColor(B1, B2, pulse);

    // Desenhar o gradiente
    let gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, backgroundColorA);
    gradient.addColorStop(1, backgroundColorB);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function interpolateColor(color1, color2, factor) {
    const c1 = hexToRgb(color1);
    const c2 = hexToRgb(color2);

    const r = Math.round(c1.r + (c2.r - c1.r) * factor);
    const g = Math.round(c1.g + (c2.g - c1.g) * factor);
    const b = Math.round(c1.b + (c2.b - c1.b) * factor);

    return rgbToHex(r, g, b);
}

function hexToRgb(hex) {
    // Remove o '#' se estiver presente
    hex = hex.replace(/^#/, '');

    let bigint = parseInt(hex, 16);
    let r, g, b;

    if (hex.length === 6) {
        r = (bigint >> 16) & 255;
        g = (bigint >> 8) & 255;
        b = bigint & 255;
    } else if (hex.length === 3) {
        r = (bigint >> 8) & 15;
        g = (bigint >> 4) & 15;
        b = bigint & 15;

        r = r * 17;
        g = g * 17;
        b = b * 17;
    } else {
        throw new Error('Formato de cor inválido: ' + hex);
    }

    return { r, g, b };
}

function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
        const hex = x.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    }).join('');
}

// Desenha a raquete
function drawPaddle() {
    const palette = levelPalettes[(level - 1) % levelPalettes.length];
    const paddleColor = palette.paddleColor;

    ctx.save(); // Salvar o estado atual do contexto

    // Configurar o efeito de brilho
    ctx.shadowBlur = 20; // Ajuste o valor conforme necessário
    ctx.shadowColor = paddleColor;

    ctx.beginPath();
    ctx.fillStyle = paddleColor;
    ctx.fillRect(paddle.x, paddle.y, paddle.width, paddle.height);
    ctx.closePath();

    ctx.restore(); // Restaurar o estado anterior do contexto
}

// Desenha as bolas
function drawBalls() {
    for (let ball of balls) {
        if (ball.isFireball) {
            // Criar partículas atrás da fireball
            createFireParticles(ball);

            // Desenhar a fireball com efeito brilhante
            ctx.save();
            ctx.beginPath();
            ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);

            // Criar gradiente radial para a fireball
            let gradient = ctx.createRadialGradient(ball.x, ball.y, ball.radius / 2, ball.x, ball.y, ball.radius);
            gradient.addColorStop(0, '#FFFF00'); // Amarelo
            gradient.addColorStop(1, '#FF4500'); // Laranja Vermelho

            ctx.fillStyle = gradient;
            ctx.shadowBlur = 20;
            ctx.shadowColor = '#FF4500';
            ctx.fill();
            ctx.closePath();
            ctx.restore();
        } else {
            // Desenhar bola normal
            ctx.beginPath();
            ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
            const palette = levelPalettes[(level - 1) % levelPalettes.length];
            const ballColor = palette.ballColor;
            ctx.fillStyle = ballColor;
            ctx.fill();
            ctx.closePath();
        }
    }
}

function drawHUD() {
    ctx.font = canvas.width * 0.03 + GAME_FONT_ROBOTO;
    const palette = levelPalettes[(level - 1) % levelPalettes.length];
    const paddleColor = palette.paddleColor;
    ctx.fillStyle = paddleColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';

    const hudText = `${difficultyConfig.difficultyName}${HUD_SEPARATOR}Level: ${level}${HUD_SEPARATOR}Lives: ${lives}${HUD_SEPARATOR}Score: ${score}`;
    ctx.fillText(hudText, canvas.width / 2, canvas.height * 0.02);
}

// Movimenta a raquete
function updatePaddle(deltaTime) {
    // Armazenar posição anterior
    paddle.previousX = paddle.x;
    paddle.previousY = paddle.y;
    
    // Update Paddle Size
    paddleWidth = calcPaddleWidth();
    paddleHeight = calcPaddleHeight();

    // Assign new dimensions to the paddle
    let previousWidth = paddle.width;
    paddle.width = paddleWidth;
    paddle.height = paddleHeight;

    // Adjust paddle position to keep it centered
    paddle.x += (previousWidth - paddle.width) / 2;

    // Apply friction when there's no input
    if (!leftPressed && !rightPressed) {
        paddle.dx *= 0.9; // Adjust the friction coefficient as needed
    }

    // Atualizar posição com base no deltaTime
    paddle.x += paddle.dx * deltaTime;

    // Prevent the paddle from moving out of the canvas boundaries
    if (paddle.x < 0) {
        paddle.x = 0;
        paddle.dx = 0;
    } else if (paddle.x + paddle.width > canvas.width) {
        paddle.x = canvas.width - paddle.width;
        paddle.dx = 0;
    }

    if (isInitialBall) positionInitialBall();
}

// Movimenta as bolas
function moveBalls(deltaTime) {
    for (let i = 0; i < balls.length; i++) {
        let ball = balls[i];

        // Armazenar posição anterior
        ball.previousX = ball.x;
        ball.previousY = ball.y;

        // Atualizar posição com base no deltaTime
        ball.x += ball.dx * deltaTime;
        ball.y += ball.dy * deltaTime;

        // Colisão com paredes laterais
        if (ball.x - ball.radius < 0) {
            ball.x = ball.radius;
            ball.dx = Math.abs(ball.dx);
        } else if (ball.x + ball.radius > canvas.width) {
            ball.x = canvas.width - ball.radius;
            ball.dx = -Math.abs(ball.dx);
        }

        // Colisão com o teto
        if (ball.y - ball.radius < 0) {
            ball.y = ball.radius;
            ball.dy = Math.abs(ball.dy);
        }

        // Perda de vida ou remoção da bola
        if (ball.y - ball.radius > canvas.height) {
            balls.splice(i, 1);
            i--;

            if (balls.length <= 0) {
                lives--;
                score = Math.max(score - (GAME_LIFELOSS_POINTS_PENALTY * difficultyConfig.scoreMultiplier), 0);
                if (lives > 0) {
                    initLevel();
                } else {
                    gameState = 'gameOver';
                    // Exibir tela de game over
                }
                return false; // Sair da função e avisar pra não prosseguir no processamento, pois perdeu uma vida e o estado do jogo mudou
            }
        }
    }
    return true; // Sinaliza que OK para prosseguir
}

function lineIntersectsRect(x1, y1, x2, y2, rx, ry, rw, rh) {
    // Verifica se a linha colide com algum dos lados do retângulo
    return (
        lineIntersectsLine(x1, y1, x2, y2, rx, ry, rx + rw, ry) || // topo
        lineIntersectsLine(x1, y1, x2, y2, rx, ry, rx, ry + rh) || // esquerdo
        lineIntersectsLine(x1, y1, x2, y2, rx + rw, ry, rx + rw, ry + rh) || // direito
        lineIntersectsLine(x1, y1, x2, y2, rx, ry + rh, rx + rw, ry + rh) // base
    );
}

function lineIntersectsLine(x1, y1, x2, y2, x3, y3, x4, y4) {
    // Função auxiliar que verifica se duas linhas se interceptam
    let denominator = ((y4 - y3) * (x2 - x1)) - ((x4 - x3) * (y2 - y1));
    if (denominator === 0) return false;

    let ua = (((x4 - x3) * (y1 - y3)) - ((y4 - y3) * (x1 - x3))) / denominator;
    let ub = (((x2 - x1) * (y1 - y3)) - ((y2 - y1) * (x1 - x3))) / denominator;

    return (ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1);
}

function circleIntersectsRectangle(previousX, previousY, currentX, currentY, radius, rectX, rectY, rectWidth, rectHeight) {
    // Encontrar o ponto mais próximo no retângulo para o círculo
    const closestX = clamp(currentX, rectX, rectX + rectWidth);
    const closestY = clamp(currentY, rectY, rectY + rectHeight);
    
    // Calcular a distância entre o círculo e esse ponto
    const distanceX = currentX - closestX;
    const distanceY = currentY - closestY;
    
    // Calcular a distância quadrada
    const distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);
    
    return distanceSquared < (radius * radius);
}

// Detecção de colisão com pads e bricks
// Função de detecção de colisão com pads e bricks
function collisionDetection() {
    for (let ball of balls) {
        // Usar posição anterior armazenada
        let previousX = ball.previousX;
        let previousY = ball.previousY;
        let radius = ball.radius;

        // Verificar colisão com os blocos
        for (let r = 0; r < brickRowCount; r++) {
            for (let c = 0; c < brickColumnCount; c++) {
                let b = bricks[r][c];
                if (b && (b.status > 0 || b.unbreakable)) {
                    // Verificar colisão usando CCD com o raio da bola
                    if (
                        circleIntersectsRectangle(
                            previousX,
                            previousY,
                            ball.x,
                            ball.y,
                            radius,
                            b.x,
                            b.y,
                            b.width,
                            b.height
                        )
                    ) {
                        // Determinar o lado da colisão
                        let collisionSide = getCollisionSide(ball, b);

                        // Determinar se a bola deve refletir
                        let shouldBounce = false;

                        if (b.unbreakable) {
                            shouldBounce = true;
                        } else if (!ball.isFireball) {
                            shouldBounce = true;
                        }

                        if (shouldBounce) {
                            // Reverter movimento para posição anterior
                            ball.x = previousX;
                            ball.y = previousY;

                            // Ajustar direção da bola conforme o lado da colisão
                            if (collisionSide === 'top') {
                                ball.dy = -Math.abs(ball.dy);
                                ball.y = b.y - ball.radius;
                            } else if (collisionSide === 'bottom') {
                                ball.dy = Math.abs(ball.dy);
                                ball.y = b.y + b.height + ball.radius;
                            } else if (collisionSide === 'left') {
                                ball.dx = -Math.abs(ball.dx);
                                ball.x = b.x - ball.radius;
                            } else if (collisionSide === 'right') {
                                ball.dx = Math.abs(ball.dx);
                                ball.x = b.x + b.width + ball.radius;
                            }
                        }

                        // Lógica de colisão com blocos
                        if (b.unbreakable) {
                            // Sem pontuação ao atingir bloco inquebrável
                        } else {
                            if (ball.isFireball) {
                                // Destruir o bloco instantaneamente
                                const pointsForAllHits = (GAME_BASE_HIT_POINTS * b.status) * difficultyConfig.scoreMultiplier;

                                if (b.hasPowerUp) {
                                    score += GAME_POWERUP_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                    generatePowerUp(b.x + b.width / 2, b.y + b.height / 2);
                                }

                                score += pointsForAllHits;
                                b.status = 0;

                                createParticles(ball.x, ball.y);

                                if (checkWin()) {
                                    doLevelCompleted();
                                    return;
                                }
                            } else if (b.status > 1) {
                                // Diminuir o status do bloco
                                b.status -= 1;
                                score += GAME_BASE_HIT_POINTS * difficultyConfig.scoreMultiplier * b.status;
                            } else {
                                // Destruir o bloco
                                b.status = 0;

                                if (b.hasPowerUp) {
                                    generatePowerUp(b.x + b.width / 2, b.y + b.height / 2);
                                    score += GAME_POWERUP_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                } else {
                                    score += GAME_BASE_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                }

                                createParticles(ball.x, ball.y);

                                if (checkWin()) {
                                    doLevelCompleted();
                                    return;
                                }
                            }
                        }

                        // Se a bola refletiu, sair do loop de colunas
                        if (shouldBounce) {
                            break;
                        } else {
                            // Continuar verificando outros blocos
                            continue;
                        }
                    }
                }
            }
        }

        // Verificar colisão com a raquete usando CCD
        if (
            ball.dy > 0 && // A bola está se movendo para baixo
            circleIntersectsRectangle(
                previousX,
                previousY,
                ball.x,
                ball.y,
                ball.radius,
                paddle.x,
                paddle.y,
                paddle.width,
                paddle.height
            )
        ) {
            // Reverter movimento para posição anterior
            ball.x = previousX;
            ball.y = previousY;

            // Calcular o ponto de colisão na raquete
            let collidePoint = (ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
            collidePoint = clamp(collidePoint, -1, 1); // Limitar entre -1 e 1

            let angle = collidePoint * (Math.PI / 3); // Máximo de 60 graus

            ball.dx = ball.speed * Math.sin(angle);
            ball.dy = -Math.abs(ball.speed * Math.cos(angle));

            // Ajustar a posição da bola para o topo da raquete
            ball.y = paddle.y - ball.radius;
        }

        // Paliativo: Verificar se a bola está dentro de algum bloco inquebrável
        for (let r = 0; r < brickRowCount; r++) {
            for (let c = 0; c < brickColumnCount; c++) {
                let b = bricks[r][c];
                if (b && b.unbreakable) {
                    if (
                        circleIntersectsRectangle(
                            ball.x,
                            ball.y,
                            ball.radius,
                            b.x,
                            b.y,
                            b.width,
                            b.height
                        )
                    ) {
                        // Determinar o lado da colisão novamente
                        let collisionSide = getCollisionSide(ball, b);

                        // Ajustar a posição da bola para fora do bloco
                        if (collisionSide === 'top') {
                            ball.dy = -Math.abs(ball.dy);
                            ball.y = b.y - ball.radius;
                        } else if (collisionSide === 'bottom') {
                            ball.dy = Math.abs(ball.dy);
                            ball.y = b.y + b.height + ball.radius;
                        } else if (collisionSide === 'left') {
                            ball.dx = -Math.abs(ball.dx);
                            ball.x = b.x - ball.radius;
                        } else if (collisionSide === 'right') {
                            ball.dx = Math.abs(ball.dx);
                            ball.x = b.x + b.width + ball.radius;
                        }
                    }
                }
            }
        }
    }
}

// Função para clonar um objeto
function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

// Função para normalizar um vetor
function normalize(dx, dy) {
    let length = Math.hypot(dx, dy);
    if (length === 0) return { dx: 0, dy: 0 };
    return { dx: dx / length, dy: dy / length };
}

// Função de detecção e resolução de colisão entre bolas
function ballCollisionDetection() {
    for (let i = 0; i < balls.length; i++) {
        for (let j = i + 1; j < balls.length; j++) {
            let ballA = balls[i];
            let ballB = balls[j];

            let dx = ballB.x - ballA.x;
            let dy = ballB.y - ballA.y;
            let distance = Math.hypot(dx, dy);
            let minDist = ballA.radius + ballB.radius;

            if (distance < minDist) {
                // Calcular a direção normal da colisão
                let { dx: nx, dy: ny } = normalize(dx, dy);

                // Calcular a sobreposição
                let overlap = minDist - distance;

                // Ajustar as posições para eliminar a sobreposição
                ballA.x -= nx * (overlap / 2);
                ballA.y -= ny * (overlap / 2);
                ballB.x += nx * (overlap / 2);
                ballB.y += ny * (overlap / 2);

                // Calcular as componentes das velocidades na direção da colisão
                let velocityA = ballA.dx * nx + ballA.dy * ny;
                let velocityB = ballB.dx * nx + ballB.dy * ny;

                // Trocar as componentes das velocidades
                let temp = velocityA;
                velocityA = velocityB;
                velocityB = temp;

                // Atualizar as velocidades das bolas
                ballA.dx += (velocityA - (ballA.dx * nx + ballA.dy * ny)) * nx;
                ballA.dy += (velocityA - (ballA.dx * nx + ballA.dy * ny)) * ny;
                ballB.dx += (velocityB - (ballB.dx * nx + ballB.dy * ny)) * nx;
                ballB.dy += (velocityB - (ballB.dx * nx + ballB.dy * ny)) * ny;

                // Normalizar as velocidades para manter a velocidade constante
                let speedA = Math.hypot(ballA.dx, ballA.dy);
                let speedB = Math.hypot(ballB.dx, ballB.dy);

                if (speedA > 0) {
                    ballA.dx = (ballA.dx / speedA) * ballA.speed;
                    ballA.dy = (ballA.dy / speedA) * ballA.speed;
                }
                if (speedB > 0) {
                    ballB.dx = (ballB.dx / speedB) * ballB.speed;
                    ballB.dy = (ballB.dy / speedB) * ballB.speed;
                }
            }
        }
    }

    // Paliativo: Verificar e corrigir sobreposições persistentes
    for (let i = 0; i < balls.length; i++) {
        for (let j = i + 1; j < balls.length; j++) {
            let ballA = balls[i];
            let ballB = balls[j];

            let dx = ballB.x - ballA.x;
            let dy = ballB.y - ballA.y;
            let distance = Math.hypot(dx, dy);
            let minDist = ballA.radius + ballB.radius;

            if (distance < minDist) {
                // Calcular a direção normal da colisão
                let { dx: nx, dy: ny } = normalize(dx, dy);

                // Calcular a sobreposição
                let overlap = minDist - distance;

                // Ajustar as posições para eliminar a sobreposição
                ballA.x -= nx * (overlap / 2);
                ballA.y -= ny * (overlap / 2);
                ballB.x += nx * (overlap / 2);
                ballB.y += ny * (overlap / 2);

                // Opcional: Ajustar as velocidades para evitar futuras colisões imediatas
                ballA.dx = Math.cos(angle) * ballA.speed;
                ballA.dy = Math.sin(angle) * ballA.speed;
                ballB.dx = Math.cos(angle + Math.PI) * ballB.speed;
                ballB.dy = Math.sin(angle + Math.PI) * ballB.speed;

                // Log de depuração (opcional)
                // console.warn(`Correção paliativa de sobreposição entre bola ${i} e bola ${j}`);
            }
        }
    }
}

function doLevelCompleted() {
    gameState = 'levelCompleted';
    score += (GAME_LEVELCOMPLETE_POINTS * difficultyConfig.scoreMultiplier);
    levelCompletionTime = Date.now();
    levelCompletionElapsedTime = 0; // Resetar o tempo acumulado
}

// Detecção de colisão da bola com os blocos e com a raquete
function collisionDetection() {
    for (let ball of balls) {
        // Usar posição anterior armazenada
        let previousX = ball.previousX;
        let previousY = ball.previousY;
        let radius = ball.radius;

        // verificar colisão com os blocos
        for (let r = 0; r < brickRowCount; r++) {
            for (let c = 0; c < brickColumnCount; c++) {
                let b = bricks[r][c];
                if (b && (b.status > 0 || b.unbreakable)) {
                    // Verificar colisão usando CCD com o raio da bola
                    if (
                        circleIntersectsRectangle(
                            previousX,
                            previousY,
                            ball.x,
                            ball.y,
                            radius,
                            b.x,
                            b.y,
                            b.width,
                            b.height
                        )
                    ) {
                        // Reverter movimento para posição anterior
                        ball.x = previousX;
                        ball.y = previousY;

                        // Determinar o lado da colisão
                        let collisionSide = getCollisionSide(ball, b);

                        // Determinar se a bola deve refletir
                        let shouldBounce = false;

                        if (b.unbreakable) {
                            shouldBounce = true;
                        } else if (!ball.isFireball) {
                            shouldBounce = true;
                        }

                        // Ajustar direção da bola se necessário
                        if (shouldBounce) {
                            if (collisionSide === 'top') {
                                ball.dy = -Math.abs(ball.dy);
                                ball.y = b.y - ball.radius;
                            } else if (collisionSide === 'bottom') {
                                ball.dy = Math.abs(ball.dy);
                                ball.y = b.y + b.height + ball.radius;
                            } else if (collisionSide === 'left') {
                                ball.dx = -Math.abs(ball.dx);
                                ball.x = b.x - ball.radius;
                            } else if (collisionSide === 'right') {
                                ball.dx = Math.abs(ball.dx);
                                ball.x = b.x + b.width + ball.radius;
                            }
                        } else {
                            // Mover a bola levemente para evitar múltiplas colisões com o mesmo bloco
                            ball.x += ball.dx * 0.1;
                            ball.y += ball.dy * 0.1;
                        }

                        // Lógica de colisão com blocos
                        if (b.unbreakable) {
                            // Sem pontuação ao atingir bloco inquebrável
                        } else {
                            if (ball.isFireball) {
                                // Destruir o bloco instantaneamente
                                const pointsForAllHits = (GAME_BASE_HIT_POINTS * b.status) * difficultyConfig.scoreMultiplier;

                                if (b.hasPowerUp) {
                                    score += GAME_POWERUP_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                    generatePowerUp(b.x + b.width / 2, b.y + b.height / 2);
                                }

                                score += pointsForAllHits;
                                b.status = 0;

                                createParticles(ball.x, ball.y);

                                if (checkWin()) {
                                    doLevelCompleted();
                                    return;
                                }
                            } else if (b.status > 1) {
                                // Diminuir o status do bloco
                                b.status -= 1;
                                score += GAME_BASE_HIT_POINTS * difficultyConfig.scoreMultiplier * b.status;
                            } else {
                                // Destruir o bloco
                                b.status = 0;

                                if (b.hasPowerUp) {
                                    generatePowerUp(b.x + b.width / 2, b.y + b.height / 2);
                                    score += GAME_POWERUP_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                } else {
                                    score += GAME_BASE_HIT_POINTS * difficultyConfig.scoreMultiplier;
                                }

                                createParticles(ball.x, ball.y);

                                if (checkWin()) {
                                    doLevelCompleted();
                                    return;
                                }
                            }
                        }

                        // Se a bola refletiu, sair do loop
                        if (shouldBounce) {
                            break;
                        } else {
                            // Continuar verificando outros blocos
                            continue;
                        }
                    }
                }
            }
        }

        // Verificar colisão com a raquete usando CCD
        if (
            ball.dy > 0 && // A bola está se movendo para baixo
            lineIntersectsRect(
                previousX,
                previousY,
                ball.x,
                ball.y,
                paddle.x,
                paddle.y,
                paddle.width,
                paddle.height
            )
        ) {
            // Reverter movimento para posição anterior
            ball.x = previousX;
            ball.y = previousY;

            // Calcular o ponto de colisão na raquete
            let collidePoint = (ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
            let angle = collidePoint * (Math.PI / 3); // Máximo de 60 graus

            ball.dx = ball.speed * Math.sin(angle);
            ball.dy = -Math.abs(ball.speed * Math.cos(angle));

            // Ajustar a posição da bola para o topo da raquete
            ball.y = paddle.y - ball.radius;
        }
    }
}

function rectsMovingIntersect(prevX1, prevY1, currX1, currY1, width1, height1,
    prevX2, prevY2, currX2, currY2, width2, height2) {
    // Cria retângulos que cobrem as áreas percorridas pelos objetos
    let minX1 = Math.min(prevX1, currX1);
    let maxX1 = Math.max(prevX1 + width1, currX1 + width1);
    let minY1 = Math.min(prevY1, currY1);
    let maxY1 = Math.max(prevY1 + height1, currY1 + height1);

    let minX2 = Math.min(prevX2, currX2);
    let maxX2 = Math.max(prevX2 + width2, currX2 + width2);
    let minY2 = Math.min(prevY2, currY2);
    let maxY2 = Math.max(prevY2 + height2, currY2 + height2);

    // Verifica se os retângulos se sobrepõem
    return !(maxX1 < minX2 || maxX2 < minX1 || maxY1 < minY2 || maxY2 < minY1);
}

function getCollisionSide(ball, brick) {
    let ballCenterX = ball.x;
    let ballCenterY = ball.y;
    let brickCenterX = brick.x + brick.width / 2;
    let brickCenterY = brick.y + brick.height / 2;

    let dx = (ballCenterX - brickCenterX) / (brick.width / 2);
    let dy = (ballCenterY - brickCenterY) / (brick.height / 2);

    if (Math.abs(dx) > Math.abs(dy)) {
        return dx > 0 ? 'right' : 'left';
    } else {
        return dy > 0 ? 'bottom' : 'top';
    }
}

//Função auxiliar para limitar um valor dentro de um intervalo.
function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function movePowerUps(deltaTime) {
    for (let i = 0; i < powerUps.length; i++) {
        let pu = powerUps[i];
        if (pu.active) {
            // Armazenar posição anterior
            pu.previousX = pu.x;
            pu.previousY = pu.y;

            const powerUpSpeed = canvas.height * 0.2; // Velocidade de queda dos power-ups

            // Atualizar posição com base no deltaTime
            pu.y += (powerUpSpeed * deltaTime * difficultyConfig.speedMultiplier);

            // Colisão com a raquete considerando o movimento de ambos
            if (rectsMovingIntersect(
                pu.previousX, pu.previousY, pu.x, pu.y, pu.width, pu.height,
                paddle.previousX, paddle.previousY, paddle.x, paddle.y, paddle.width, paddle.height
            )) {
                pu.active = false;
                activatePowerUp(pu.type);
                powerUps.splice(i, 1);
                i--;
                continue; // Ir para o próximo power-up
            }

            // Remove power-up se sair da tela
            if (pu.y > canvas.height) {
                powerUps.splice(i, 1);
                i--;
                continue;
            }
        }
    }
}

// Desenha os blocos
function drawBricks() {
    const palette = levelPalettes[(level - 1) % levelPalettes.length];
    const brickColor = palette.brickColor;

    // Criar um padrão para os blocos inquebráveis
    const unbreakablePattern = createUnbreakablePattern();

    let time, pulse;

    for (let r = 0; r < brickRowCount; r++) {
        for (let c = 0; c < brickColumnCount; c++) {
            let b = bricks[r][c];
            if (b && (b.status > 0 || b.unbreakable)) {
                let brickX = c * (brickWidth + brickPadding) + offsetLeft;
                let brickY = r * (brickHeight + brickPadding) + offsetTop;
                b.x = brickX;
                b.y = brickY;

                let color;

                if (b.unbreakable) {
                    // Aplicar o padrão aos blocos inquebráveis
                    ctx.fillStyle = unbreakablePattern;
                } else if (b.hasPowerUp) {
                    
                    // Calcular o fator de pulsação baseado no tempo
                    time = Date.now() * 0.005; // Ajuste a velocidade conforme necessário
                    pulse = 0.5 + 0.5 * Math.sin(time); // Varia entre 0 e 1

                    /*// Ajustar a opacidade com base no efeito de pulsação
                    ctx.fillStyle = hexToRGBA(brickColor, pulse);*/
                    ctx.fillStyle = shadeColor(brickColor, pulse);

                    // Adicionar contorno brilhante
                    ctx.save(); // Salvar o estado atual do contexto
                    ctx.shadowBlur = 10; // Ajuste o valor conforme necessário
                    ctx.shadowColor = brickColor;

                    ctx.fillRect(brickX, brickY, brickWidth, brickHeight);

                    ctx.restore(); // Restaurar o estado anterior do contexto
                } else {
                    // Ajustar a cor com base no status do bloco
                    const intensity = b.status / maxStatus; // Valor entre 0 e 1
                    color = shadeColor(brickColor, intensity);
                }

                ctx.fillStyle = color;
                ctx.fillRect(brickX, brickY, brickWidth, brickHeight);

                // Desenhar símbolo no bloco com power-up
                if (b.hasPowerUp) {
                    ctx.fillStyle = `rgba(255, 255, 255, ${pulse})`; // Ajustar a opacidade do símbolo
                    ctx.font = brickWidth * 0.4 + GAME_FONT_ROBOTO;
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText('?', brickX + (brickWidth / 2), brickY + (brickHeight / 2));
                }
            }
        }
    }
}

function createUnbreakablePattern() {
    // Criar um canvas temporário para o padrão
    const patternCanvas = document.createElement('canvas');
    const patternSize = 20; // Tamanho do padrão
    patternCanvas.width = patternSize;
    patternCanvas.height = patternSize;
    const pctx = patternCanvas.getContext('2d');

    // Desenhar o padrão (listras diagonais)
    pctx.strokeStyle = '#555555'; // Cor das listras
    pctx.lineWidth = 2;
    pctx.beginPath();
    pctx.moveTo(0, 0);
    pctx.lineTo(patternSize, patternSize);
    pctx.stroke();
    pctx.beginPath();
    pctx.moveTo(patternSize, 0);
    pctx.lineTo(0, patternSize);
    pctx.stroke();

    // Criar o padrão
    return ctx.createPattern(patternCanvas, 'repeat');
}

function invertColor(hex) {
    const c = hexToRgb(hex);
    const r = 255 - c.r;
    const g = 255 - c.g;
    const b = 255 - c.b;
    return rgbToHex(r, g, b);
}

function hexToRGBA(hex, alpha) {
    const c = hexToRgb(hex);
    return `rgba(${c.r}, ${c.g}, ${c.b}, ${alpha})`;
}

// Função auxiliar para ajustar a cor
function shadeColor(color, intensity) {
    const c = hexToRgb(color);
    const R = Math.round(c.r * intensity);
    const G = Math.round(c.g * intensity);
    const B = Math.round(c.b * intensity);

    return rgbToHex(R, G, B);
}

// Verifica se o jogador venceu
function checkWin() {
    for (let r = 0; r < brickRowCount; r++) {
        for (let c = 0; c < brickColumnCount; c++) {
            let b = bricks[r][c];
            if (b && b.status > 0 && !b.unbreakable) {
                return false;
            }
        }
    }
    return true;
}

// Event Handlers para controle da raquete
function keyDownHandler(e) {
    if(e.key === 'ArrowRight') {
        paddle.dx = paddle.speed;
        rightPressed = true;
    }
    if(e.key === 'ArrowLeft') {
        paddle.dx = -paddle.speed;
        leftPressed = true;
    }
}

function keyUpHandler(e) {
    if(e.key === 'ArrowRight') {
        if (paddle.dx > 0) paddle.dx = 0;
        rightPressed = false;
    }
    if(e.key === 'ArrowLeft') {
        if (paddle.dx < 0) paddle.dx = 0;
        leftPressed = false;
    }
}

function mouseMoveHandler(e) {
    if (gameState !== 'playing' || isPaused) return;
    let relativeX = e.clientX - canvas.getBoundingClientRect().left;
    let canvasWidth = canvas.getBoundingClientRect().width;
    if(relativeX > 0 && relativeX < canvasWidth) {
        paddle.x = relativeX / canvasWidth * canvas.width - paddle.width / 2;
    }
    if (isInitialBall) positionInitialBall();
}

function positionInitialBall() {
    if (gameState !== 'playing') return;
    if (!isInitialBall) return;
    if (isPaused) return;
    if (!balls || !balls[0] || !paddle) return;

    balls[0].x = paddle.x + (paddle.width/2);
    balls[0].y = paddle.y - balls[0].radius;
}

// Sistema de partículas para colisões
function createParticles(x, y) {
    for(let i = 0; i < 10; i++) {
        particles.push({
            x: x,
            y: y,
            dx: (Math.random() * 2 - 1) * PARTICLE_SPEED, // Velocidade horizontal
            dy: (Math.random() * 2 - 1) * PARTICLE_SPEED, // Velocidade vertical
            life: PARTICLE_LIFE
        });
    }
}

function updateParticles(deltaTime) {
    for(let i = 0; i < particles.length; i++) {
        let p = particles[i];
        p.x += p.dx * deltaTime; // Atualiza a posição horizontal
        p.y += p.dy * deltaTime; // Atualiza a posição vertical
        p.life -= deltaTime;     // Reduz a vida da partícula

        if(p.life <= 0) {
            particles.splice(i, 1);
            i--;
        }
    }
    updateFireParticles(deltaTime);
}

function drawParticles() {
    for(let p of particles) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${p.life / PARTICLE_LIFE})`; // Opacidade baseada na vida
        ctx.fill();
        ctx.closePath();
    }
}

// Sistema de power-ups
function generatePowerUp(x, y) {
    let type = POWERUP_TYPES[Math.floor(Math.random() * POWERUP_TYPES.length)];
    const pillWidth = canvas.width * 0.06;
    const pillHeight = canvas.height * 0.02;

    powerUps.push({
        x: x,
        y: y,
        width: pillWidth,
        height: pillHeight,
        type: type,
        active: true,
        previousX: x,
        previousY: y
    });
}

function activatePowerUp(type) {
    let message = '';

    switch(type) {
        case POWERUP_TYPES[FIREBALL]:
            message = 'Fireball';
            // Cancelar efeitos de fastball e slowball
            activePowerUps.fastball = 0;
            activePowerUps.slowball = 0;
            // Ativar fireball
            activePowerUps.fireball = FIREBALL_DURATION;
            // As bolas existentes se tornam fireballs
            for (let ball of balls) {
                ball.isFireball = true;
            }
            break;
        case POWERUP_TYPES[MULTIBALL]:
            message = 'Multi Ball';
            createMultipleBalls();
            break;
        case POWERUP_TYPES[BIGPADDLE]:
            message = 'BIG Paddle';
            powerupBigPaddleMultiplier *= 2;
            // Armazene o setTimeout em um array para poder cancelá-lo depois
            let bigPaddleTimeout = setTimeout(() => { 
                powerupBigPaddleMultiplier /= 2; 
            }, POWERUP_DURATION * 1000);
            powerupTimeouts.push(bigPaddleTimeout);
            break;
        case POWERUP_TYPES[SLOWBALL]:
            if (activePowerUps.fireball > 0) {
                // Ignorar slowball durante fireball
                return;
            }
            message = 'Slow Ball';
            // Cancelar fastball se estiver ativo
            activePowerUps.fastball = 0;
            // Estender ou iniciar slowball
            activePowerUps.slowball += POWERUP_DURATION;
            break;
        case POWERUP_TYPES[EXTRALIFE]:
            message = 'Extra Life';
            lives++;
            break;
        case POWERUP_TYPES[FASTBALL]:
            if (activePowerUps.fireball > 0) {
                // Ignorar fastball durante fireball
                return;
            }
            message = 'Fast Ball';
            // Cancelar slowball se estiver ativo
            activePowerUps.slowball = 0;
            // Estender ou iniciar fastball
            activePowerUps.fastball += POWERUP_DURATION;
            break;
        default:
            message = 'ERROR: type ' + type + ' unknown';
            break;
    }

    createEffectMessage(paddle.x + paddle.width / 2, paddle.y, message);
}

function cancelPowerUpTimeouts() {
    // Cancelar todos os timeouts pendentes
    powerupTimeouts.forEach(timeoutId => clearTimeout(timeoutId));
    powerupTimeouts = []; // Limpar o array após cancelar
}

function updatePowerUpEffects(deltaTime) {
    let ballSpeedMultiplier = 1;

    // Atualizar fastball
    if (activePowerUps.fastball > 0) {
        activePowerUps.fastball -= deltaTime;
        if (activePowerUps.fastball <= 0) {
            activePowerUps.fastball = 0;
        }
        ballSpeedMultiplier = POWERUP_FASTBALL_MULTIPLIER;
    }

    // Atualizar slowball
    if (activePowerUps.slowball > 0) {
        activePowerUps.slowball -= deltaTime;
        ballSpeedMultiplier = POWERUP_SLOWBALL_MULTIPLIER;
        if (activePowerUps.slowball <= 0) {
            activePowerUps.slowball = 0;
        }
    }

    // Atualizar fireball
    if (activePowerUps.fireball > 0) {
        activePowerUps.fireball -= deltaTime;
        if (activePowerUps.fireball <= 0) {
            // Desativar fireball
            activePowerUps.fireball = 0;
            for (let ball of balls) {
                ball.isFireball = false;
            }
        } else {
            ballSpeedMultiplier = POWERUP_SLOWBALL_MULTIPLIER; // fireball é sempre SLOW
        }
    }

    activePowerupBalspeedModifier = ballSpeedMultiplier;
    applyBallSpeedToAllBalls();
}

function applyBallSpeedToAllBalls() {
    for (let ball of balls) {
        const ballSpeed = calcBallSpeed();

        ball.speed = ballSpeed;

        // Atualizar dx e dy mantendo a direção
        const angle = Math.atan2(ball.dy, ball.dx);
        ball.dx = ballSpeed * Math.cos(angle);
        ball.dy = ballSpeed * Math.sin(angle);
    }
}

function drawPowerUps() {
    for (let pu of powerUps) {
        if (pu.active) {
            const pillWidth = canvas.width * 0.06;
            const pillHeight = canvas.height * 0.02;
            pu.width = pillWidth;
            pu.height = pillHeight;

            const x = pu.x - pillWidth / 2;
            const y = pu.y - pillHeight / 2;

            // Definir a cor do power-up
            let gradient = ctx.createLinearGradient(x, y, x + pillWidth, y);
            switch (pu.type) {
                case POWERUP_TYPES[FIREBALL]:
                    gradient.addColorStop(0, '#FF0000'); // Vermelho
                    gradient.addColorStop(0.5, '#FFFF00'); // Amarelo
                    gradient.addColorStop(1, '#FF0000'); // Vermelho
                    break;
                case POWERUP_TYPES[FASTBALL]:
                    // Novo gradiente simplificado para Fastball
                    gradient.addColorStop(0, '#FADA28'); // Amarelo bruguer
                    gradient.addColorStop(0.2, '#DAA520'); // Amarelo goldenrod
                    gradient.addColorStop(0.4, '#FADA28'); // Amarelo bruguer
                    gradient.addColorStop(0.6, '#DAA520'); // Amarelo goldenrod
                    gradient.addColorStop(0.8, '#FADA28'); // Amarelo bruguer
                    gradient.addColorStop(1, '#DAA520'); // Amarelo goldenrod
                    break;
                case POWERUP_TYPES[EXTRALIFE]:
                    gradient.addColorStop(0, '#FFFFFF'); // Branco
                    gradient.addColorStop(0.4, '#FFFFFF'); // Branco
                    gradient.addColorStop(0.5, '#FF0000'); // Vermelho
                    gradient.addColorStop(0.6, '#FFFFFF'); // Branco
                    gradient.addColorStop(1, '#FFFFFF'); // Branco
                    break;
                case POWERUP_TYPES[SLOWBALL]:
                    // Gradiente mais suave para Slowball
                    gradient.addColorStop(0, '#00BFFF'); // Azul claro
                    gradient.addColorStop(1, '#1C1C1C'); // Cinza mais escuro
                    break;
                case POWERUP_TYPES[BIGPADDLE]:
                    // Gradiente verde e azul para indicar crescimento
                    gradient.addColorStop(0, '#00FF00'); // Verde claro
                    gradient.addColorStop(1, '#00CED1'); // Azul claro
                    break;
                case POWERUP_TYPES[MULTIBALL]:
                    // Criar um gradiente arco-íris
                    gradient.addColorStop(0, '#FF0000'); // Vermelho
                    gradient.addColorStop(0.2, '#FFA500'); // Laranja
                    gradient.addColorStop(0.4, '#FFFF00'); // Amarelo
                    gradient.addColorStop(0.6, '#008000'); // Verde
                    gradient.addColorStop(0.8, '#0000FF'); // Azul
                    gradient.addColorStop(1, '#4B0082'); // Índigo
                    break;
                // Outros power-ups
                default:
                    gradient.addColorStop(0, '#FFFFFF'); // Branco
                    gradient.addColorStop(1, '#000000'); // Preto
                    break;
                }

            ctx.fillStyle = gradient;

            // Desenhar a pílula
            ctx.beginPath();
            ctx.moveTo(x + pillHeight / 2, y);
            ctx.lineTo(x + pillWidth - pillHeight / 2, y);
            ctx.quadraticCurveTo(x + pillWidth, y, x + pillWidth, y + pillHeight / 2);
            ctx.lineTo(x + pillWidth, y + pillHeight - pillHeight / 2);
            ctx.quadraticCurveTo(x + pillWidth, y + pillHeight, x + pillWidth - pillHeight / 2, y + pillHeight);
            ctx.lineTo(x + pillHeight / 2, y + pillHeight);
            ctx.quadraticCurveTo(x, y + pillHeight, x, y + pillHeight - pillHeight / 2);
            ctx.lineTo(x, y + pillHeight / 2);
            ctx.quadraticCurveTo(x, y, x + pillHeight / 2, y);
            ctx.closePath();
            ctx.fill();
        }
    }
}

function createMultipleBalls() {
    const numBalls = Math.floor(Math.random() * 3) + 1; // De 1 a 3 bolas adicionais
    const speed = balls[0].speed;
    const ballRadius = balls[0].radius;

    for (let i = 0; i < numBalls; i++) {
        const angle = (-Math.PI / 2) + (Math.random() * Math.PI / 4) - (Math.PI / 8); // Direção para cima com variação

        balls.push({
            x: paddle.x + paddle.width / 2,
            y: paddle.y - ballRadius,
            radius: ballRadius,
            speed: speed,
            dx: speed * Math.cos(angle),
            dy: speed * Math.sin(angle),
            isFireball: false
        });
    }
}

function createEffectMessage(x, y, text) {
    effects.push({
        x: x,
        y: y,
        text: text,
        opacity: 1,
        scale: 1.2,
        duration: 60 // Duração em frames
    });
}

function updateEffects(deltaTime) {
    for(let i = 0; i < effects.length; i++) {
        let effect = effects[i];
        effect.opacity -= (1 / effect.duration) * deltaTime * 60; // Ajuste para deltaTime
        effect.scale -= 0.01 * deltaTime * 60;
        effect.y -= 60 * deltaTime; // Move para cima, ajustado para deltaTime
        if(effect.opacity <= 0 || effect.scale <= 0) {
            effects.splice(i, 1);
            i--;
        }
    }
}

function drawEffects() {
    for(let effect of effects) {
        ctx.save();
        ctx.globalAlpha = effect.opacity;
        ctx.font = canvas.width * 0.03 * effect.scale + GAME_FONT_ARIAL;
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'center';
        ctx.fillText(effect.text, effect.x, effect.y);
        ctx.restore();
    }
}

function drawLevelCompletion(deltaTime) {
    // Acumular o tempo decorrido
    levelCompletionElapsedTime += deltaTime;

    // Usar o mesmo fundo pulsante do nível atual
    drawPulsatingBackground(level, deltaTime);

    // Calcular o fator de pulsação baseado no tempo acumulado
    const time = levelCompletionElapsedTime * 2; // Ajuste a velocidade conforme necessário
    const pulse = (Math.sin(time) + 1) / 2; // Varia entre 0 e 1

    // Interpolar a cor do texto
    const palette = levelPalettes[(level - 1) % levelPalettes.length];
    const textColorStart = '#FFFFFF'; // Cor inicial do texto (branco)
    const textColorEnd = palette.paddleColor; // Podemos usar a cor da raquete como cor final

    const textColor = interpolateColor(textColorStart, textColorEnd, pulse);

    // Texto de nível concluído
    ctx.font = 'bold ' + canvas.width * 0.08 + GAME_FONT_ARIAL;
    ctx.fillStyle = textColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    ctx.fillText('Level ' + level + ' Complete', canvas.width / 2, canvas.height / 2);

    // Adicione efeitos animados aqui (por exemplo, partículas ou transições)
}

function togglePause() {
    if (gameState === 'playing') {
        isPaused = !isPaused;
        if (isPaused) {
            drawPauseScreen();
        } else {
            // Continuar o jogo
        }
    }
}

function drawPauseScreen() {
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'; // Fundo semitransparente
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.font = 'bold ' + canvas.width * 0.08 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Game Paused', canvas.width / 2, canvas.height / 2);

    drawGameNameAndVersion();

    ctx.restore();
}

function createMenuParticles() {
    // Cria as partículas para o menu (tanto para o Start Menu quanto para Game Over)
    for (let i = 0; i < 100; i++) { // Número de partículas aumentadas para uma estética mais rica
        menuParticles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            dx: (Math.random() * 2 - 1) * MENU_PARTICLE_SPEED, // Velocidade horizontal (pixels/segundo)
            dy: (Math.random() * 2 - 1) * MENU_PARTICLE_SPEED, // Velocidade vertical (pixels/segundo)
            radius: Math.random() * 3 + 1,
            alpha: Math.random() * 0.5 + 0.5, // Alpha entre 0.5 e 1
        });
    }
}

// Função para desenhar o fundo do menu
function drawMenuBackground(deltaTime) {
    // Limpar o canvas
    clearCanvas();

    if (!menuParticles) { createMenuParticles(); }

    // Atualizar o tempo acumulado
    menuBackgroundTime += deltaTime;

    // Gradiente de fundo animado (alterando as cores com o tempo)
    let time = menuBackgroundTime * 10; // Controle da animação do gradiente
    let gradientColor1, gradientColor2;

    if (gameState === 'gameOver') {
        // Cores dramáticas para Game Over
        gradientColor1 = `hsl(${(time + 240) % 360}, 80%, 20%)`; // Tons de preto/roxo escuro
        gradientColor2 = `hsl(${(time + 120 + 240) % 360}, 80%, 10%)`; // Ajuste para manter o deslocamento de cor
    } else if (gameState === 'gameCompleted') {
        // Cores mais alegres para o Game Completed
        gradientColor1 = `hsl(${(time) % 360}, 100%, 60%)`; // Cores vibrantes
        gradientColor2 = `hsl(${(time + 120) % 360}, 100%, 50%)`;
    } else {
        // Cores vivas para o Start Menu
        gradientColor1 = `hsl(${(time) % 360}, 80%, 50%)`; // HSL para cores cíclicas e animadas
        gradientColor2 = `hsl(${(time + 120) % 360}, 80%, 50%)`; // Um pouco defasada em relação à primeira cor
    }

    let gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, gradientColor1);
    gradient.addColorStop(1, gradientColor2);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Atualizar e desenhar partículas
    updateMenuParticles(deltaTime);
    drawMenuParticles();
}

function updateMenuParticles(deltaTime) {
    for (let i = 0; i < menuParticles.length; i++) {
        let p = menuParticles[i];
        p.x += p.dx * deltaTime; // Atualiza a posição horizontal
        p.y += p.dy * deltaTime; // Atualiza a posição vertical
        p.life -= deltaTime;     // Reduz a vida da partícula

        // Rebater partículas nas bordas do canvas
        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
    }
}

function drawMenuParticles() {
    for (let p of menuParticles) {
        // Verificar se os valores são finitos
        if (!isFinite(p.x) || !isFinite(p.y) || !isFinite(p.radius)) {
            continue; // Ignorar partículas inválidas
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);

        let particleColor;
        if (gameState === 'gameOver') {
            particleColor = `rgba(255, 0, 0, ${p.alpha})`; // Vermelho dramático para Game Over
        } else if (gameState === 'gameCompleted') {
            particleColor = `rgba(0, 255, 0, ${p.alpha})`; // Verde vibrante para Game Completion
        } else if (gameState === 'startMenu') {
            particleColor = `rgba(255, 255, 255, ${p.alpha})`; // Partículas brancas para o Start Menu
        }

        // Criar gradiente radial
        let particleGradient;
        try {
            particleGradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius);
        } catch (error) {
            console.error('Erro ao criar gradiente radial:', error);
            continue; // Ignorar esta partícula se houver erro
        }

        particleGradient.addColorStop(0, particleColor);
        particleGradient.addColorStop(1, `rgba(255, 255, 255, 0)`);

        ctx.fillStyle = particleGradient;
        ctx.fill();
    }
}

function drawStartMenu(deltaTime) {
    drawMenuBackground(deltaTime);

    const buttonWidth = canvas.width * 0.5;
    const buttonHeight = canvas.height * 0.1;
    const buttonSpacing = canvas.height * 0.05; // Espaçamento entre os botões
    const totalButtonHeight = (buttonHeight + buttonSpacing) * gameDifficulties.length - buttonSpacing; // Altura total dos botões (com espaçamento)
    const totalHeight = totalButtonHeight + canvas.height * 0.1; // Altura total do texto e botões
    const verticalCenter = (canvas.height - totalHeight) / 2; // Calcular o centro vertical

    const buttonX = (canvas.width - buttonWidth) / 2;
    const mainText = "Let's play"; // Texto principal
    const textColor = '#FFFFFF'; // branco para o start

    // Desenhar o título da tela (Welcome ou Try Again)
    ctx.font = 'bold ' + canvas.width * 0.09 + GAME_FONT_ARIAL;
    ctx.fillStyle = textColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(mainText, canvas.width / 2, verticalCenter);

    // Desenhar os botões de dificuldade
    startButtons = []; // Limpar array de botões antes de redesenhar

    gameDifficulties.forEach((difficulty, index) => {
        const buttonY = verticalCenter + canvas.height * 0.1 + (index * (buttonHeight + buttonSpacing)); // Posicionamento dos botões abaixo do texto

        // Armazenar as coordenadas do botão para detecção de clique
        startButtons.push({
            difficulty: difficulty.difficultyName,
            x: buttonX,
            y: buttonY,
            width: buttonWidth,
            height: buttonHeight
        });

        // Detectar se o mouse está sobre o botão para efeito de destaque
        const isMouseOver = mouseX >= buttonX && mouseX <= buttonX + buttonWidth &&
                            mouseY >= buttonY && mouseY <= buttonY + buttonHeight;

        ctx.fillStyle = isMouseOver ? ('#FFD700') : ('#FFFFFF');
        ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);

        ctx.font = 'bold ' + canvas.width * 0.04 + GAME_FONT_ARIAL;
        ctx.fillStyle = '#000000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(difficulty.difficultyName, canvas.width / 2, buttonY + buttonHeight / 2);
    });

    drawGameNameAndVersion();
}

function drawGameNameAndVersion() {
    // Exibir o nome e a versão do jogo no canto inferior direito
    ctx.font = 'bold ' + canvas.width * 0.02 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'bottom';
    ctx.fillText(GAME_NAME_HUD + ' v' + GAME_VERSION, canvas.width - 10, canvas.height - 10);
}

function drawGameOverScreen(deltaTime) {
    drawMenuBackground(deltaTime); // Fundo dramático de Game Over

    const verticalCenter = canvas.height * 0.3; // Posicionar o texto no terço superior da tela

    // Desenhar o título "Game Over"
    ctx.font = 'bold ' + canvas.width * 0.1 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FF0000'; // Cor dramática vermelha
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Game Over', canvas.width / 2, verticalCenter);

    // Exibir as informações relevantes do jogo
    ctx.font = 'bold ' + canvas.width * 0.05 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFFFFF'; // Texto em branco
    ctx.fillText(`Difficulty: ${difficultyConfig.difficultyName}`, canvas.width / 2, verticalCenter + 80);
    ctx.fillText(`Level reached: ${level}`, canvas.width / 2, verticalCenter + 140);
    ctx.fillText(`Final score: ${score}`, canvas.width / 2, verticalCenter + 200);

    // Adicionar botão "Back to Menu"
    const buttonWidth = canvas.width * 0.4;
    const buttonHeight = canvas.height * 0.08;
    const buttonX = (canvas.width - buttonWidth) / 2;
    const buttonY = verticalCenter + 280;

    // Detectar se o mouse está sobre o botão para efeito de destaque
    const isMouseOver = mouseX >= buttonX && mouseX <= buttonX + buttonWidth &&
    mouseY >= buttonY && mouseY <= buttonY + buttonHeight;

    // Desenhar o botão
    ctx.fillStyle = isMouseOver ? ('#FFD700') : ('#FF0000');
    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);

    ctx.font = 'bold ' + canvas.width * 0.04 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#000000'; // Preto para o texto do botão
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Back to Menu', canvas.width / 2, buttonY + buttonHeight / 2);

    // Adicionar clique no botão "Back to Menu"
    startButtons = [{
        x: buttonX,
        y: buttonY,
        width: buttonWidth,
        height: buttonHeight,
        action: function () {
            gameState = 'startMenu'; // Voltar ao menu principal
        }
    }];

    // Manter partículas e fundo dinâmico
    updateMenuParticles();
    drawMenuParticles();
}

function drawGameCompletion(deltaTime) {
    drawMenuBackground(deltaTime); // Usar fundo animado para o game completion

    const verticalCenter = canvas.height * 0.3; // Posicionar o texto no terço superior da tela

    // Desenhar o título "Congratulations!!!" com efeito de glow
    ctx.save();
    ctx.font = 'bold ' + canvas.width * 0.1 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFD700'; // Dourado para dar destaque
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowBlur = 30;
    ctx.shadowColor = '#FFD700'; // Efeito de glow dourado
    ctx.fillText('Congratulations!!!', canvas.width / 2, verticalCenter);
    ctx.restore(); // Restaurar o contexto para evitar interferir nos próximos elementos

    // Exibir a mensagem de agradecimento
    ctx.font = 'bold ' + canvas.width * 0.05 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFFFFF'; // Texto em branco
    ctx.fillText('Thank you for playing my game!', canvas.width / 2, verticalCenter + 100);

    // Assinatura menor e em itálico, alinhada à direita
    ctx.font = 'italic ' + canvas.width * 0.035 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#FFFFFF'; // Texto em branco
    ctx.textAlign = 'right';
    ctx.fillText('- Rodolfo Motta Saraiva', canvas.width * 0.9, verticalCenter + 150);

    // Exibir as informações de jogo (dificuldade, nível, pontuação)
    ctx.font = 'bold ' + canvas.width * 0.04 + GAME_FONT_ARIAL;
    ctx.textAlign = 'center';
    ctx.fillText(`Difficulty: ${difficultyConfig.difficultyName}`, canvas.width / 2, verticalCenter + 240);
    ctx.fillText(`Level reached: ${level}`, canvas.width / 2, verticalCenter + 300);
    ctx.fillText(`Final score: ${score}`, canvas.width / 2, verticalCenter + 360);

    // Adicionar botão "Back to Menu"
    const buttonWidth = canvas.width * 0.4;
    const buttonHeight = canvas.height * 0.08;
    const buttonX = (canvas.width - buttonWidth) / 2;
    const buttonY = verticalCenter + 420;

    // Detectar se o mouse está sobre o botão para efeito de destaque
    const isMouseOver = mouseX >= buttonX && mouseX <= buttonX + buttonWidth &&
    mouseY >= buttonY && mouseY <= buttonY + buttonHeight;

    // Desenhar o botão
    ctx.fillStyle = isMouseOver ? '#FFD700' : '#00FF00'; // Verde vibrante para o botão
    ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);

    ctx.font = 'bold ' + canvas.width * 0.04 + GAME_FONT_ARIAL;
    ctx.fillStyle = '#000000'; // Preto para o texto do botão
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Back to Menu', canvas.width / 2, buttonY + buttonHeight / 2);

    // Adicionar clique no botão "Back to Menu"
    startButtons = [{
        x: buttonX,
        y: buttonY,
        width: buttonWidth,
        height: buttonHeight,
        action: function () {
            gameState = 'startMenu'; // Voltar ao menu principal
        }
    }];

    // Manter partículas e fundo dinâmico
    updateMenuParticles();
    drawMenuParticles();
}

function startOrRestartGame(selectedDifficulty) {
    difficultyConfig = gameDifficulties.find(d => d.difficultyName === selectedDifficulty);
    if (!difficultyConfig) {
        // if not found, falls back to default
        difficultyConfig = gameDifficulties[0];
    }
    // (re)iniciar o jogo
    resetGame();
    init();
}

// Função para criar partículas na bola de fogo, com fogo e fumaça
function createFireParticles(ball) {
    for (let i = 0; i < 5; i++) {
        // Partículas de fogo
        fireParticles.push({
            x: ball.x,
            y: ball.y,
            dx: (Math.random() * 2 - 1) * FIRE_PARTICLE_SPEED, // Velocidade horizontal
            dy: (Math.random() * 2 - 1) * FIRE_PARTICLE_SPEED, // Velocidade vertical
            life: FIRE_PARTICLE_LIFE,
            initialLife: FIRE_PARTICLE_LIFE, // Para calcular a opacidade
            size: FIRE_PARTICLE_SIZE,
            color: `rgba(255, ${Math.floor(Math.random() * 150 + 100)}, 0, 1)` // Vermelho/Amarelo com opacidade total
        });

        // Partículas de fumaça
        fireParticles.push({
            x: ball.x,
            y: ball.y,
            dx: (Math.random() * 2 - 1) * (FIRE_PARTICLE_SPEED / 2), // Velocidade horizontal reduzida
            dy: (Math.random() * 2 - 1) * (FIRE_PARTICLE_SPEED / 2), // Velocidade vertical reduzida
            life: FIRE_PARTICLE_LIFE * 1.5,
            initialLife: FIRE_PARTICLE_LIFE * 1.5, // Para calcular a opacidade
            size: FIRE_PARTICLE_SIZE * 1.2, // Tamanho maior para partículas de fumaça
            color: `rgba(100, 100, 100, 0.5)` // Cinza com opacidade reduzida
        });
    }
}

function updateFireParticles(deltaTime) {
    for (let i = fireParticles.length - 1; i >= 0; i--) {
        let p = fireParticles[i];
        p.x += p.dx * deltaTime; // Atualiza a posição horizontal
        p.y += p.dy * deltaTime; // Atualiza a posição vertical
        p.life -= deltaTime;     // Reduz a vida da partícula

        // Diminui o tamanho gradualmente
        p.size *= 0.95; // Reduz o tamanho em 5% a cada frame

        // Atualizar a cor com base na vida restante
        let lifeRatio = p.life / p.initialLife; // Valor entre 0 e 1
        if (p.color.startsWith('rgba(255')) {
            // Partículas de fogo: ajusta a opacidade
            p.color = `rgba(255, ${Math.floor(Math.random() * 150 + 100)}, 0, ${lifeRatio})`;
        } else {
            // Partículas de fumaça: ajusta a opacidade
            p.color = `rgba(100, 100, 100, ${0.5 * lifeRatio})`;
        }

        // Remove a partícula se sua vida útil acabar ou tamanho for muito pequeno
        if (p.life <= 0 || p.size <= 0.5) {
            fireParticles.splice(i, 1);
        }
    }
}

// Desenha as partículas
function drawFireParticles() {
    for (let p of fireParticles) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
        ctx.closePath();
    }
}

function addMouseEventsListeners() {
    canvas.addEventListener('click', function(event) {
        let rect = canvas.getBoundingClientRect();
        let mouseX = event.clientX - rect.left;
        let mouseY = event.clientY - rect.top;

        if (gameState === 'startMenu' && startButtons.length > 0) {
            // Verificar se o clique ocorreu em algum dos botões de dificuldade
            for (let button of startButtons) {
                if (
                    mouseX >= button.x &&
                    mouseX <= button.x + button.width &&
                    mouseY >= button.y &&
                    mouseY <= button.y + button.height
                ) {
                    // Iniciar o jogo com a dificuldade selecionada
                    startOrRestartGame(button.difficulty);
                    return;
                }
            }
        } else if (gameState === 'playing') {
            if (isInitialBall) {
                isInitialBall = false;
            } else {
                togglePause();
            }
        } else if ((gameState === 'gameOver' || gameState === 'gameCompleted') && startButtons.length > 0) {
            for (let button of startButtons) {
                if (
                    mouseX >= button.x &&
                    mouseX <= button.x + button.width &&
                    mouseY >= button.y &&
                    mouseY <= button.y + button.height
                ) {
                    button.action(); // Executar ação do botão
                    return;
                }
            }
        }
    });

    // Adicionar um listener de movimento do mouse para capturar a posição do mouse
    canvas.addEventListener('mousemove', function(event) {
        let rect = canvas.getBoundingClientRect();
        mouseX = event.clientX - rect.left;
        mouseY = event.clientY - rect.top;

        if (gameState === 'playing' && !isPaused) {
            let canvasWidth = canvas.getBoundingClientRect().width;
            if(mouseX > 0 && mouseX < canvasWidth) {
                paddle.x = mouseX / canvasWidth * canvas.width - paddle.width / 2;
            }
            if (isInitialBall) positionInitialBall();
        }
    });
}

// Função para carregar múltiplas variantes da fonte Roboto
async function loadFonts() {
    try {
        if (document.fonts && document.fonts.load) {
            // Carregar Regular (400), Light (300) e Bold (700), além de Italic
            await Promise.all([
                document.fonts.load('300 100px Roboto'),
                document.fonts.load('400 100px Roboto'),
                document.fonts.load('700 100px Roboto'),
                document.fonts.load('italic 400 100px Roboto'),
                document.fonts.load('italic 700 100px Roboto')
            ]);
            console.log('Todas as variantes da fonte Roboto foram carregadas.');
        } else {
            console.warn('API de Font Loading não suportada. Usando fontes fallback.');
        }
    } catch (error) {
        console.error('Erro ao carregar as fontes Roboto:', error);
    }
}


// Iniciar o jogo após as fontes serem carregadas
(async function initializeGame() {
    await loadFonts();
    resizeCanvas(true);
    window.addEventListener('resize', resizeCanvas);
    createMenuParticles();
    createIntroParticles();
    gameLoop();
})();
